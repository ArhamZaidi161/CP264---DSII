#ifndef MYCHAR_H  
#define MYCHAR_H

int mytype(char c);

char case_flip(char c);

int digit_to_int(char c); 

#endif